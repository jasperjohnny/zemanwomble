




/*
     FILE ARCHIVED ON 4:03:37 Oct 27, 2016 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 5:25:27 Jan 21, 2017.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/* flDefault-1.0.0.js */

// init
$(function(){
	var html = $('html');
	html.removeClass('no-js');
	var supportsTouch = 'ontouchstart' in window || 'onmsgesturechange' in window;
	if(supportsTouch){
		html.addClass('yes-touch');
	}else{
		html.addClass('no-touch');
	}
});

// scripts
/******************************
Disclaimer v3.0
Author: Derrick Gall
Copyright: FindLaw, a Thomson Reuters business
Description: Will fix short form disclaimer popup position issues.
******************************/
$(function(){var e="a.intakeFormShortDisclaimerLink",d="#intakeFormShortDisclaimer a",b=$(e),c=$(d),a=$(b.attr("href"));setTimeout(function(){b.replaceWith(b.clone());c.replaceWith(c.clone());$(e+","+d).bind("click",function(f){if(a.is(":visible")){a.hide()}else{a.show()}f.preventDefault()})},500)});

/******************************
Highlight v3.0
Author: Derrick Gall
Copyright: FindLaw, a Thomson Reuters business
Description: Used to apply over/active states to images/anchors and also supports rollovers on images/image inputs.
******************************/
if(typeof highlightOptions!=="object"){highlightOptions={}}

highlightOptions = $.extend({
	/******************************
		CUSTOMIZE HIGHLIGHT HERE
	******************************/
	disableActiveLink: false,
	disableActiveHover: true,
	activeImages: [],
	excludedLinks: {},
	includedLinks: {},
	activeClass: 'current',
	preloadImages: true,
	highlightHome: false
}, highlightOptions);

function highlight(d){var i,l,e=location.protocol+"//"+location.host,g=e.length,c,n=[],f=0,m,h="",o="",a=[],k="",j="",b=location.href;d=$.extend({disableActiveLink:false,disableActiveHover:false,activeImages:[],excludedLinks:null,includedLinks:null,activeClass:"current",preloadImages:true,pageID:"",pageSection:"",pageSectionTop:""},d);m=function(s){var r=this,t=0,p="",q="";this.src=s.src;this.state="";if(this.src.indexOf("-o.")>-1){this.src=this.src.replace("-o.",".")}if(this.src.indexOf("blank.gif")>-1){this.isPNG=true;this.src=s.runtimeStyle.filter.replace(/.*?src='([^']*)'.*/gi,"$1")}else{this.isPNG=false}t=this.src.lastIndexOf(".");p=this.src.substring(0,t);q=this.src.substring(t,this.src.length);this.overStateImage=p+"-o"+q;this.activeStateImage=p+"-a"+q;this.switchTo=function(u){switch(u){case"over":r.src=r.overStateImage;break;case"active":r.src=r.activeStateImage;break}r.state=u};this.updateElement=function(u){if(u){s.className=s.className.replace(/(^| )over(?: |$)/gi,"$1")}if(!r.isPNG){s.src=r.src}else{s.runtimeStyle.filter="progid:DXImageTransform.Microsoft.AlphaImageLoader(src='"+r.src+"',sizingMethod='scale')"}};this.initRollover=function(){var w=r.overStateImage,y=null,z=r.src,v=null,u=null,x=null;if(r.state==="active"&&d.disableActiveHover){return false}if(d.preloadImages){y=document.createElement("img");y.src=w;a[a.length]=y}u=$(s);if(u.is("img")){u=u.parent()}if(!r.isPNG){v=function(){s.src=w};x=function(){s.src=z}}else{v=function(){s.runtimeStyle.filter="progid:DXImageTransform.Microsoft.AlphaImageLoader(src='"+w+"',sizingMethod='scale')"};x=function(){s.runtimeStyle.filter="progid:DXImageTransform.Microsoft.AlphaImageLoader(src='"+z+"',sizingMethod='scale')"}}u.bind("mouseover focus",v).bind("mouseout blur",x)}};c=function(s){var r=0,t=null,q=s.getElementsByTagName("img"),p=[];if(q&&q.length){for(r=0;r<q.length;r++){t=q[r];if(t.className.match(/(^| )(over|pngOver)( |$)/gi)){p[p.length]=new m(t)}}}return p};if(d.pageID!=="${page.ID}"&&d.pageID!==""){h="";if(d.pageID===d.pageSection){h="/"+d.pageID+"/"}else{if(d.pageSection&&d.pageSection===d.pageSectionTop){h="/"+d.pageSection}h=h+"/"+d.pageID+".shtml"}k="/"+d.pageSection+"/";j="/"+d.pageSectionTop+"/"}else{o=b.replace(/[^:]*:\/\/[^\/]*(.*)/gi,"$1");if(b.indexOf("previewsite.do")>-1||b.indexOf("JSPeditPageContent.do")>-1){if(FSFilename==="index"){h="/"+FSPageGroup+"/"}else{h="/"+FSFilename+".shtml";if(FSPageGroup){h="/"+FSPageGroup+h}}k="/"+FSPageGroup+"/"}else{h=o;k=o.match(/^(\/[^\/]+\/)/gi);if(k){k=k[0]}else{k="//"}}j="//"}if(h==="/Home.shtml"){h="/"}i=function(){var q=0,t=d.includedLinks,u=null,s="",p=[],r=0;if(t!==null){for(u in t){if(t.hasOwnProperty(u)){p=t[u];if(u&&p){r=p.length;for(q=0;q<r;q++){s=p[q];if(h.match(new RegExp(s,"gi"))){n[n.length]=u;break}}}}}}f=n.length};l=function(){var E=d.activeImages.length,I="",H="",A="",r=null,G=document.getElementsByTagName("a"),s=G.length,t=null,p=d.excludedLinks,w=[],v=0,D=0,C=0,B=0,z=null,x=null,F=0,y=null,q=null,u=0,K=false,J=false;for(D=0;D<s;D++){r=G[D];H=r.href;A="";x=c(r);F=x.length;if(H.indexOf(e)>-1){A=H.substring(g,H.length);J=false;K=false;if(p!==null){for(t in p){if(p.hasOwnProperty(t)){if(A.match(new RegExp(t,"gi"))){if(!p[t]){K=true;break}else{if(p[t]===true&&!h.match(t)){K=true;break}else{w=p[t];if(w[0]){v=w.length;for(C=0;C<v;C++){if(h.match(new RegExp(w[C],"gi"))){K=true;break}}}}}}}}}if(h==="/"&&A==="/"&&!d.highlightHome){K=true}if(!K){for(C=0;C<f;C++){if(A.match(new RegExp(n[C],"gi"))){J=true;break}}if(A===h||J||A===k||A===j||A===j+k.substring(1)||A===j+k.substring(1)+h.substring(1)){r.className+=" "+d.activeClass;if(d.disableActiveLink){r.removeAttribute("href")}if(F){for(C=0;C<F;C++){z=x[C];for(B=0;B<E;B++){I=d.activeImages[B];if(z.src.indexOf(I)>-1){z.switchTo("active");break}}if(z.state!=="active"){z.switchTo("over")}z.updateElement(true)}}}}}if(F){for(C=0;C<F;C++){x[C].initRollover()}}}q=document.getElementsByTagName("input");u=q.length;for(D=0;D<u;D++){y=q[D];if(y.type==="image"&&y.className.match(/(^| )over( |$)/gi)){z=new m(y);z.initRollover()}}};i();l()}$(function(){highlight(highlightOptions)});

/*! appendAround markup pattern. [c]2012, @scottjehl, Filament Group, Inc. MIT/GPL */
(function(a){a.fn.appendAround=function(){return this.each(function(){function c(){b.is(":hidden")&&b.appendTo(d.filter(":visible:eq(0)"))}var b=a(this),d=a("[data-set='"+b.closest("[data-set]").attr("data-set")+"']");c();a(window).resize(c)})}})(jQuery);