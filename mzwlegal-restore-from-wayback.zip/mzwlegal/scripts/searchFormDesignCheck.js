




/*
     FILE ARCHIVED ON 12:31:06 Oct 27, 2016 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 5:25:26 Jan 21, 2017.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
// Search Form Check (re-evaluated) v1.1 by Derrick Gall (May 2009)

if (!$('script[src$="searchFormDesignCheck.js"]:first').attr('hasexecuted')) {

	$().ready(function(){
		if (location.href.match(/previewsite.do\?pagename=/)) {
			$('#searchFormDesign,#searchForm').submit(function(e){
				e.preventDefault();
				alert('Search does not function from Preview, please use your published Web site to search.');
			});
		}
	});

	$('script[src$="searchFormDesignCheck.js"]:first').attr('hasexecuted', true);
}